﻿#!/usr/bin/env python
# coding: utf-8

# In[3]:


import sys
import pandas as pd
import numpy as np
import nltk
import re
import requests as rs
# nltk.download('stopwords')
# nltk.download('punkt')
# nltk.download('ptb')
# nltk.download('maxent_treebank_pos_tagger')
# nltk.download('averaged_perceptron_tagger')
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer 
from gensim.summarization import summarize


# In[10]:


def sentiment_scores(sentence_list):
    
    sent_list = []
    
    # Create a SentimentIntensityAnalyzer object. 
    sid_obj = SentimentIntensityAnalyzer() 
    
    for sentence in sentence_list:
        # polarity_scores method of SentimentIntensityAnalyzer 
        # oject gives a sentiment dictionary. 
        # which contains pos, neg, neu, and compound scores. 
        sent_dict = sid_obj.polarity_scores(sentence)
        sent_list.append(sent_dict)
        
    sentiment_df = pd.DataFrame(sent_list)   
    
    return sentiment_df


# In[17]:


def conclude(row):
    if ((row['pos']+row['neu']) >= 0.7) & (row['pos'] >= 0.2):
        val = 'Positive'
    elif ((row['neg']+row['neu']) >= 0.7) & (row['neg'] >= 0.2):
        val = 'Negative'
    else:
        val = 'Neutral'
    return val


# In[9]:


def sent_work(data, colname_s):
    
    sentiments = sentiment_scores(data[str(colname_s)].tolist())
    final_data = pd.concat([data.reset_index(drop=True), sentiments.reset_index(drop=True)], axis=1)
    final_data['sent_class'] = final_data.apply(conclude, axis=1)

    return final_data

