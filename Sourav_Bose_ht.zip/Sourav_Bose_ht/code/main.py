#!/usr/bin/env python
# coding: utf-8

import argparse
from model_nlp import ProdClassifier

parser = argparse.ArgumentParser()
parser.add_argument("--train", help="helps in Model Fitting", type=str)
parser.add_argument("--predict", help="helps in Predictions", type=str)
parser.add_argument("--method", help="helps choose the Algorithm", type=str)
parser.add_argument("--main_product", help="helps filter for a specific main Product", type=str)
args = parser.parse_args()

if args.train is not None:
	x1 = args.train.split(",")
	temp = {i[:i.find('=')]:i[i.find('=')+1:] for i in x1}

	main_only = eval(temp.get("main_only", False))
	main_product = args.main_product
	method = args.method
	if method is None:
		method = 'FT'
		
	foo = ProdClassifier()
	foo.fit(main_only = main_only, main_product = main_product, method = method, create_data=True)
	
elif args.predict is not None:

	main_product = args.main_product
	text = args.predict
	method = args.method
	if method is None:
		method = 'FT'
	foo = ProdClassifier()
	foo.predict(text = text, main_product = main_product, method = method)	
	
else:
	print('Provide value for each of these arguments.')
	print(parser.parse_args())	
