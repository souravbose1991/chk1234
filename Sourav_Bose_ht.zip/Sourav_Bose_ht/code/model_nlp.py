#!/usr/bin/env python
# coding: utf-8


import warnings
warnings.filterwarnings('ignore')

import contractions, unicodedata
from itertools import chain
from bs4 import BeautifulSoup


#NLTK
import nltk
from nltk.corpus import stopwords
from nltk import TweetTokenizer
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import RegexpTokenizer 
nltk.download('wordnet')
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
from nltk.corpus import wordnet
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer 


# Gensim
import gensim
from gensim.models import Phrases
import gensim.corpora as corpora
from gensim.utils import simple_preprocess
from gensim.models import CoherenceModel
from gensim.models import ldaseqmodel
from gensim.corpora import Dictionary, bleicorpus
from gensim.matutils import hellinger

# Plots
import pyLDAvis
import pyLDAvis.gensim  # don't skip this
import matplotlib.pyplot as plt
# %matplotlib inline

# Plotly
import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio
from plotly.subplots import make_subplots
import pandas
import string, pickle, swifter, joblib
import numpy as np
import pandas as pd
from tqdm import tqdm
import re, csv, math, codecs, glob
import os, datetime
from pathlib import Path


import fasttext as ft
from sklearn.model_selection import train_test_split
from collections import Counter

#SK-Learn
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer

from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC, SVC
from sklearn.model_selection import cross_val_score



# Keras
import keras
from keras import optimizers
from keras import backend as K
from keras import regularizers
from keras.layers import Dense, Activation, Dropout, Flatten
from keras.layers import Embedding, Conv1D, MaxPooling1D, GlobalMaxPooling1D
from keras.utils import plot_model
from keras.preprocessing import sequence
from keras.preprocessing.text import Tokenizer
from keras.callbacks import EarlyStopping
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential, load_model
from keras.layers import Dense, Flatten, LSTM, Dropout, Activation
from keras.layers import Input, Embedding, SpatialDropout1D, concatenate
from keras.layers import GRU, Bidirectional
from keras.preprocessing import text, sequence
from keras.callbacks import Callback
from keras.utils.np_utils import to_categorical
from keras.callbacks import ModelCheckpoint


# os.environ["OMP_NUM_THREADS"] = "8"

global DATA_PATH, RESULTS_PATH, MODEL_PATH

DATA_PATH = "../data"
RESULTS_PATH = "../results"
MODEL_PATH = "../model"




################## Compaint Classification into Products ##################
class ProdClassifier:
	
	'''
    This is a Class which takes care of the entire NLP Challenge which helps enhance User Experience and
    also makes this process easily implementable. The methods of this class has been appropriately put into 
    Private and Public methods, but Class Methods and Static Methods are desirable and would have been done wit more time.
    
    The Class has the following major components:
    
    1. Automatically creating a desired state of underlying directory structure with automatic 
       Data Creating / Extraction for both Main and Sub Product Classification
    
    2. The Unstructed Text data has been throughly exammined and cleansed with:
        a. HTML striping, Special Character removal, Lemmatization, StopWord removal, etc.
        b. The data had a lot of redundant and wrongly classified Main and Sub Products.
           Product Knowledge has been applied to re-classify them into meaningful categories, 
           thus reducing the sparsity of information and improving the Training data.
           
    3. Exploratory Data Analysis has been performed:
       a. Sentiment Analysis and Categorical Distribution check. Visualizations get automatically
          generated and saved in relevant locations.
       b. Topic Modelling is performed to understand more about the Unstructured text before proceeding
          to Supervised Learnings. Features from Topic Models could have been added if more time was provided.
          
    4. Model Development: Hierarchical Multi-Class Classification for Main and Sub Products with different 
       state-of-art algorithms and practices with proper Validation mechanisms:
       a. FastText 
       b. Machine Learning Algorithms with TF-IDF Feature Engineering
       c. Recurrent Deep Neural Networks
       
    5. Modularizationa and enabling Command Line operationalization
    
    
    The Class has 4 Major Public methods and a lot more private methods.
    
    1. explore_data(create_data=True, sample=None): This method extracts, creates and cleans the underlying data if required
       and then performs sentiment analysis on it. 
       a. "create_data": True will make the function always create the data. Default is False where the data would be created
          only if it doesnot exist in the required location.
       b. "sample": This lets us sample the data for further analysis if the data is too large for processing and execution.
       
    2. topics_model(): This method creates a Topic Model of the unstructured text and helps build an Interactive Visual to
       explore and understand the same.
       
    3. fit(main_only=False, main_product=None, method='ML'): This method fits the model and saves all its relevant information.
       It also does a Validation excercise for Model Selection. 
       a. "main_only": This is to be set to True when one wishes to Classify for Main Product only.
       b. "main_product": This takes in the value of a specific Main Product if one wishes to classify for Sub Product only
           falling under that category
       c. "method": This takes any of the FT | ML | DL values. It is the indicator for the algorithm to be used for Classification.
           FT - FastText, ML - Plethora of ML Classifiers, DL - recurrent Deep Neural Network
           
    4. predict(text, main_product=None, method='ML'): This method predicts based on the previously Fitted Models.
       a. "text": This is the new unstructured raw text data to be predicted. It accepts both String as well as Pandas Series objects.
       b. "main_product": This takes in the value of a specific Main Product if one wishes to predict the Sub Product only
           falling under that category
       c. "method": This takes any of the FT | ML | DL values. It is the indicator for the algorithm to be used for Prediction.
           FT - FastText, ML - Plethora of ML Classifiers, DL - recurrent Deep Neural Network
           
    
    All of the above methods can take many other popular Key-word arguments that can be passed through for model hyperparameters, 
    data filtering, and inherits them appropriately.
       
    The Command Line Operationalization also takes in few arguments (--train, --predict, --main_product, --method) with their usual
    definitions and usage.  
    ''' 
    
    def __init__(self, stop_words=None):
        
        if stop_words is None:
            stop_words = set(stopwords.words("english"))
            
        self.stop_words = stop_words
        self.subset_df = None
        self.sent_topics_df = None
        
        if not os.path.exists(Path(DATA_PATH).resolve().as_posix()):
            os.mkdir(Path(DATA_PATH).resolve().as_posix())
            
        if not os.path.exists(Path(MODEL_PATH).resolve().as_posix()):
            os.mkdir(Path(MODEL_PATH).resolve().as_posix())
            
        if not os.path.exists(Path(RESULTS_PATH).resolve().as_posix()):
            os.mkdir(Path(RESULTS_PATH).resolve().as_posix())
        
        if not os.path.exists(Path(DATA_PATH).resolve().as_posix()+"/clean_data"):
            os.mkdir(Path(DATA_PATH).resolve().as_posix()+"/clean_data")
            

    
    ################## Transcript Text Cleaning ##################
    
    # Lemmatize with POS Tag
    def __get_wordnet_pos(self, word):
        """Map POS tag to first character lemmatize() accepts"""
        tag = nltk.pos_tag([word])[0][1][0].upper()
        tag_dict = {"J": wordnet.ADJ,
                    "N": wordnet.NOUN,
                    "V": wordnet.VERB,
                    "R": wordnet.ADV}
        return tag_dict.get(tag, wordnet.NOUN)

    def __strip_html_tags(self, text):
        soup = BeautifulSoup(text, "html.parser")
        [s.extract() for s in soup(['iframe', 'script'])]
        stripped_text = soup.get_text()
        stripped_text = re.sub(r'[\r|\n|\r\n]+', '\n', stripped_text)
        return stripped_text

    def __remove_accented_chars(self, text):
        text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8', 'ignore')
        return text

    def __expand_contractions(self, text):
        return contractions.fix(text)

    def __remove_special_characters(self, text, remove_digits=False):
        pattern = r'[^a-zA-Z0-9\s]' if not remove_digits else r'[^a-zA-Z\s]'
        text = re.sub(pattern, '', text)
        return text

    def __pre_process_document(self, document, label=False):        
        # converting to text
        document =  str(document)

        # strip HTML
        document = self.__strip_html_tags(document)

        # lower case
        document = document.lower()

        # remove extra newlines (often might be present in really noisy text)
        document = document.translate(document.maketrans("\n\t\r", "   "))

        # remove accented characters
        document = self.__remove_accented_chars(document)
        document = re.sub(r"x+", "", document)
        document = re.sub(r"(<br/>)", "", document)
        document = re.sub(r"(<a).*(>).*(</a>)", "", document)
        document = re.sub(r"(&amp)", "", document)
        document = re.sub(r"(&gt)", "", document)
        document = re.sub(r"(&lt)", "", document)
        document = re.sub(r"(\xa0)", " ", document)
                
        if not label:
            # remove special characters and\or digits    
            # insert spaces between special characters to isolate them    
            special_char_pattern = re.compile(r'([{.(-)!}])')
            document = special_char_pattern.sub(" \\1 ", document)
            document = self.__remove_special_characters(document, remove_digits=True)  

        # remove extra whitespace
        document = re.sub(' +', ' ', document)
        document = document.strip()

        if not label:
            # Split the documents into tokens.
            tokenizer = RegexpTokenizer(r'\w+')
            document = document.lower()  # Convert to lowercase.
            document = tokenizer.tokenize(document)  # Split into words.

            # Remove numbers, but not words that contain numbers.
            # Remove words that are only one character.
            # Remove stopwords
            document = [token for token in document if not token.isnumeric()]
            document = [token for token in document if len(document) > 1]   
            document = [word for word in document if not word in self.stop_words]
            document = " ".join(document)

            # expand contractions    
            document = self.__expand_contractions(document)

            # lemmatize
            document = document.split()
            lemmatizer = WordNetLemmatizer()
            document = [lemmatizer.lemmatize(word, self.__get_wordnet_pos(word)) for word in document]
            document = [word for word in document if not word in self.stop_words]
            document = " ".join(document)

        return document
    
    
    def __prepare_data(self, comb_data):
        
        print("Data preparation in progress...! \n")
        
        comb_data['SUB_PRODUCT'].loc[comb_data['SUB_PRODUCT'].isnull()] = comb_data['MAIN_PRODUCT'][comb_data['SUB_PRODUCT'].isnull()]
        comb_data['MAIN_PRODUCT'] = comb_data['MAIN_PRODUCT'].swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=True))
        comb_data['SUB_PRODUCT'] = comb_data['SUB_PRODUCT'].swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=True))
        
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='vehicle loan or lease') & (comb_data['SUB_PRODUCT']=='loan')] = 'vehicle loan'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='vehicle loan or lease') & (comb_data['SUB_PRODUCT']=='lease')] = 'vehicle lease'
        comb_data['MAIN_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='other financial service') & (comb_data['SUB_PRODUCT']=='credit repair')] = 'credit reporting, credit repair services, or other personal consumer reports'
        comb_data['MAIN_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='checking or savings account') & (comb_data['SUB_PRODUCT']=='personal line of credit')] = 'consumer loan'
        comb_data['MAIN_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='credit reporting, credit repair services, or other personal consumer reports') & (comb_data['SUB_PRODUCT']=='conventional home mortgage')] = 'mortgage'
        
        mp_replace_dict = {"credit reporting":"credit reporting, credit repair services, or other personal consumer reports",
                  "credit card":"credit card or prepaid card", "prepaid card": "credit card or prepaid card",
                  "payday loan":"consumer loan", 
                  "money transfers":"money transfer, virtual currency, or money service",
                  "vehicle loan or lease":"consumer loan", 
                  "payday loan, title loan, or personal loan":"consumer loan",
                  "virtual currency":"money transfer, virtual currency, or money service",
                  "other financial service":"money transfer, virtual currency, or money service",
                  "checking or savings account":"bank account or service"}
        
        comb_data['MAIN_PRODUCT'].replace(mp_replace_dict, inplace=True)
        
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='credit reporting, credit repair services, or other personal consumer reports') & (comb_data['SUB_PRODUCT']=='credit repair')] = 'credit repair services'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='credit card or prepaid card') & (comb_data['SUB_PRODUCT']=='government benefit payment card')] = 'government benefit card'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='bank account or service') & (comb_data['SUB_PRODUCT']=='(cd) certificate of deposit')] = 'cd (certificate of deposit)'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='bank account or service') & (comb_data['SUB_PRODUCT']=='other banking product or service')] = 'other bank product/service'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='money transfer, virtual currency, or money service') & (comb_data['SUB_PRODUCT']=="traveler's check or cashier's check")] = 'travelers/cashiers checks'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='money transfer, virtual currency, or money service') & (comb_data['SUB_PRODUCT']=='check cashing')] = 'check cashing service'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='medical')] = 'medical debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='auto')] = 'auto debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=="other (i.e. phone, health club, etc.)")] = 'other debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='credit card')] = 'credit card debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='payday loan')] = 'payday loan debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='federal student loan')] = 'federal student loan debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='non-federal student loan')] = 'non-federal student loan debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='debt collection') & (comb_data['SUB_PRODUCT']=='mortgage')] = 'mortgage debt'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='student loan') & (comb_data['SUB_PRODUCT']=='private student loan')] = 'private student loan servicing'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='student loan') & (comb_data['SUB_PRODUCT']=='non-federal student loan')] = 'non-federal student loan servicing'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='mortgage') & (comb_data['SUB_PRODUCT']=='home equity loan or line of credit')] = 'home equity loan or line of credit (heloc)'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='mortgage') & (comb_data['SUB_PRODUCT']=='other type of mortgage')] = 'other mortgage'
        comb_data['SUB_PRODUCT'].loc[(comb_data['MAIN_PRODUCT']=='mortgage') & (comb_data['SUB_PRODUCT']=='fha mortgage')] = 'conventional fixed mortgage'
        
        comb_data['COMPLAINT_TEXT'] = comb_data['COMPLAINT_TEXT'].swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=False))
        comb_data['polarity'] = comb_data['COMPLAINT_TEXT'].swifter.progress_bar(False).apply(lambda text: SentimentIntensityAnalyzer().polarity_scores(text)['compound'])
        comb_data['COMPANY_RESPONSE_TO_PUBLIC'] = comb_data['COMPANY_RESPONSE_TO_PUBLIC'].swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=False))
        comb_data['MAIN_ISSUE'] = comb_data['MAIN_ISSUE'].swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=True))
        comb_data['SUB_ISSUE'] = comb_data['SUB_ISSUE'].swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=True))
        
        self.subset_df = comb_data
        path = Path(DATA_PATH).resolve().as_posix()
        self.subset_df.to_pickle(path+'/clean_data/subset_df.pkl')
        print("Data cleaned and saved..! \n")
            
            
    
    def __force_load(self, path, sample):
        for fname in glob.glob(path+'/raw_data/*.csv'):
            if (fname.rfind('\\') == -1):
                fname2 = fname[fname.rfind('/')+1:]
            else:
                fname2 = fname[fname.rfind('\\')+1:]
            globals()[fname2[:-4]] = pd.read_csv(fname)
            print("-- Reading file " + fname2 + " in dataframe " + fname2[:-4] + " -- \n")

        comb_data = complaints_users.merge(complaints_companies, how = 'left', on='COMPLAINT_ID')
        comb_data = comb_data.drop(['DATE_x', 'DATE_y', 'WAS_USER_DISPUTED', 'WAS_RESPONSE_TIMELY'], axis = 1)
        comb_data = comb_data.merge(products, how = 'left', on='PRODUCT_ID')
        comb_data = comb_data.merge(issues, how = 'left', on='ISSUE_ID')
		
		if sample is not None:
			if sample <= len(comb_data):
				comb_data = comb_data.sample(n=sample, replace=False, random_state=42)
				comb_data = comb_data.reset_index(drop=True)

        self.__prepare_data(comb_data)
        
        
    ################## Exploratory Data Analysis Visualization ##################
    
    def __sentiment_explore(self):
        
        plot_colors = px.colors.qualitative.Bold
        fig = make_subplots(specs=[[{'secondary_y': True}]])

        main_product_list = self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).index.tolist()

        fig.add_trace(go.Bar(x=main_product_list,
                             y=self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).tolist(),
                             name='Frequency', opacity=0.3, marker = dict(color = plot_colors,)
                            ), secondary_y=True)

        for i, prod in enumerate(main_product_list):
            y_temp = self.subset_df[self.subset_df['MAIN_PRODUCT'] == prod]['polarity']
            fig.add_trace(go.Box(y=y_temp, name=prod, marker = dict(color = plot_colors[i],)), secondary_y=False)

        fig.update_layout(title = "Sentiment Polarity & Frequency for Main Products", legend_orientation="h",
                             paper_bgcolor='rgba(0,0,0,0)',  plot_bgcolor='rgba(0,0,0,0)')

        fig.update_xaxes(showticklabels=False)
        fig.update_yaxes(title_text="Sentiment Score", secondary_y= False)
        fig.update_yaxes(title_text="Frequency", secondary_y= True)
        
        pio.write_html(fig, Path(RESULTS_PATH).resolve().as_posix()+'/exploration.html')
        print("Exploratory Analysis completed & results are saved..! \n")
        
        fig.show()

        
    ################## Exploratory Analysis of the Data Sets ##################
    
    def explore_data(self, create_data=False, sample=None):
        path = Path(DATA_PATH).resolve().as_posix()
        
        if not create_data:
            file = path+"/clean_data/subset_df.pkl"
            
            if os.path.isfile(file):
                self.subset_df = pd.read_pickle(file)
                
                print("Clean Data found and loaded..! \n")
                print("Here are the loaded Main & Sub Product combinations! \n")

                for mp in self.subset_df['MAIN_PRODUCT'].unique():
                    abc = self.subset_df[self.subset_df['MAIN_PRODUCT']==mp]
                    print("MAIN PRODUCT: " + mp)
                    print("SUB PRODUCT: ")
                    print(abc['SUB_PRODUCT'].unique())
                    print("\n")
                
                self.__sentiment_explore()   
            else:
                print("Clean Data not found. Creating from Raw Files..! \n")
                self.__force_load(path, sample)
                print("Here are the final Main & Sub Product combinations! \n")
        
                for mp in self.subset_df['MAIN_PRODUCT'].unique():
                    abc = self.subset_df[self.subset_df['MAIN_PRODUCT']==mp]
                    print("MAIN PRODUCT: " + mp)
                    print("SUB PRODUCT: ")
                    print(abc['SUB_PRODUCT'].unique())
                    print("\n")
                    
                self.__sentiment_explore()
        else:
            print("Creating data from Raw Files..! \n")
            self.__force_load(path=path, sample=sample)
            print("Here are the final Main & Sub Product combinations! \n")
        
            for mp in self.subset_df['MAIN_PRODUCT'].unique():
                abc = self.subset_df[self.subset_df['MAIN_PRODUCT']==mp]
                print("MAIN PRODUCT: " + mp)
                print("SUB PRODUCT: ")
                print(abc['SUB_PRODUCT'].unique())
                print("\n")
                
            self.__sentiment_explore()
                
    
        
    ################## Topic Modelling Formatted output ##################

    def __format_topics_sentences(self):
        # Init output
        sent_topics_df = pd.DataFrame()

        # Get main topic in each document
        for i, row_list in enumerate(self.ldamodel[self.corpus]):
            row = row_list[0] if self.ldamodel.per_word_topics else row_list            
            # print(row)
            row = sorted(row, key=lambda x: (x[1]), reverse=True)
            # Get the Dominant topic, Perc Contribution and Keywords for each document
            for j, (topic_num, prop_topic) in enumerate(row):
                if j == 0:  # => dominant topic
                    wp = self.ldamodel.show_topic(topic_num)
                    topic_keywords = ", ".join([word for word, prop in wp])
                    sent_topics_df = sent_topics_df.append(pd.Series([int(topic_num+1), round(prop_topic,4), 
                                                                      topic_keywords]), ignore_index=True)
                else:
                    break
        sent_topics_df.columns = ['Dominant_Topic', 'Perc_Contribution', 'Topic_Keywords']

        # Add original text to the end of the output
        contents = pd.Series(self.texts)
        sent_topics_df = pd.concat([sent_topics_df, self.subset_df], axis=1)
        self.sent_topics_df = sent_topics_df
        self.sent_topics_df.to_pickle(Path(RESULTS_PATH).resolve().as_posix()+"/LDA/Topic_Data.pkl")
         

    ################## Defining Topic models evaluation methods ##################

    def __evaluate_topic_model(self):
        coherencemodel = CoherenceModel(model=self.ldamodel, texts=self.texts, dictionary=self.dictionary, 
                                        coherence='c_v')
        top_topics = self.ldamodel.top_topics(corpus=self.corpus, texts=self.texts, 
                                           dictionary=self.dictionary, window_size=None, 
                                           coherence='c_v', topn=20)
        # Average topic coherence is the sum of topic coherences of all topics, divided by the number of topics.
        avg_topic_coherence = sum([t[1] for t in top_topics]) / len(top_topics)
        print('Average topic coherence: %.4f.' % avg_topic_coherence)
        print('Model coherence: %.4f.' % coherencemodel.get_coherence())
        print('Perplexity: ', self.ldamodel.log_perplexity(self.corpus))
            
            
    ################## Defining Topic models Training Method ##################
    
    def topics_model(self):
        
        if not os.path.exists(Path(MODEL_PATH).resolve().as_posix()+"/LDA"):
            os.mkdir(Path(MODEL_PATH).resolve().as_posix()+"/LDA")
            
        if not os.path.exists(Path(RESULTS_PATH).resolve().as_posix()+"/LDA"):
            os.mkdir(Path(RESULTS_PATH).resolve().as_posix()+"/LDA")
        
        abc1 = self.subset_df
        print("--- Defining Topics on number of Main Products ---")
        self.num_topics = len(abc1['MAIN_PRODUCT'].unique())
        
        if (self.num_topics == 1):
            print("Only 1 Main Product found. Switching to Define Topics on number of Sub Products")
            print("--- Defining Topics on number of Sub Products ---")
            self.num_topics = len(abc1['SUB_PRODUCT'].unique())
            if (self.num_topics > 1):
                print(str(self.num_topics) + " Sub Products found. Defining this as number of Topics.")
        else:
            print(str(self.num_topics) + " Main Products found. Defining this as number of Topics.")
            
        if  (self.num_topics == 1):
            print("Cannot Define Topic Model with this limited information on both Main and Sub Product.")
            print("Stopping Execution...!")
            
        else:
            
            doc_lst = abc1['COMPLAINT_TEXT'].tolist()
            doc_lst = [nltk.word_tokenize(str(doc)) for doc in doc_lst]

            # Create Corpus
            dictionary = corpora.Dictionary(doc_lst)
            dictionary.filter_extremes(no_below=2, no_above=0.8)
            corpus = [dictionary.doc2bow(text) for text in doc_lst]

            self.texts = doc_lst
            self.dictionary = dictionary
            self.corpus = corpus
            
            print("Dictionary and Corpus created.")

            # Build LDA model
            ldamodel = gensim.models.ldamodel.LdaModel(corpus=self.corpus, id2word=self.dictionary, 
                                                        num_topics=self.num_topics, random_state=42, 
                                                        per_word_topics=True)
            
            ldamodel.print_topics()
            self.ldamodel = ldamodel
            ldamodel.save(Path(MODEL_PATH).resolve().as_posix() + '/LDA/topic_model.pkl')
            print("Topic Model created and saved succcesfully.")
            self.__evaluate_topic_model()
            self.__format_topics_sentences()

            # Visualize the topics
            pyLDAvis.enable_notebook()
            vis = pyLDAvis.gensim.prepare(ldamodel, corpus, dictionary, sort_topics = False)
            pyLDAvis.save_html(vis, Path(RESULTS_PATH).resolve().as_posix() + '/LDA/topic_lda.html')

            return vis
    
    
    ################## Classifiers #######################      
    
    def __flatten(self, listOfLists):
        "Flatten one level of nesting"
        return chain.from_iterable(listOfLists)
    
    
    
    def __get_key(self, mydict, search_val, mp_id=None): 
        
        if mp_id is None:
            for key, sub_dict in mydict.items(): 
                if (sub_dict.get('name') == search_val):
                    return key
        else:
            sub_dict = mydict.get(mp_id)
            for key, value in sub_dict.items():
                if (value == search_val):
                    return key
     
    
    
    def __get_dict(self, mp_name=None, **kwargs):
        
        model_path = Path(MODEL_PATH).resolve().as_posix()
        create_data = kwargs.get("create_data", False)
        
        if create_data:
            print("-- Creating Class Labels for Main & Sub Product classes --\n")

            mp_list = self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).index.tolist()
            dict_list = []

            for mp in mp_list:
                temp = self.subset_df[self.subset_df['MAIN_PRODUCT']==mp]
                t_dict = {'Sub'+str(i+1):sprd for i,sprd in enumerate(temp['SUB_PRODUCT'].value_counts(normalize=False).index.tolist())}
                t_dict.update({'name': mp})
                dict_list.append(t_dict)

            mydict = {'Main'+str(i+1):name for i,name in enumerate(dict_list)}

            f = open(model_path + '/Product_Dictionary.pkl','wb')
            pickle.dump(mydict,f)
            f.close()
            
            print("-- Dictionary for Main & Sub Product created and saved --\n")
            
            with open(model_path + '/Product_Dictionary.pkl', 'rb') as pickle_file:
                mydict = pickle.load(pickle_file)
        
        else:
            
            file = model_path + '/Product_Dictionary.pkl'
            
            if os.path.isfile(file):
                with open(model_path + '/Product_Dictionary.pkl', 'rb') as pickle_file:
                    mydict = pickle.load(pickle_file)
                print("Dictionary for Main & Sub Products found and loaded..! \n")
                
            else:
                print("-- Dictionary for Main & Sub Products not found. Creating it..! --\n")

                mp_list = self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).index.tolist()
                dict_list = []

                for mp in mp_list:
                    temp = self.subset_df[self.model_data['MAIN_PRODUCT']==mp]
                    t_dict = {'Sub'+str(i+1):sprd for i,sprd in enumerate(temp['SUB_PRODUCT'].value_counts(normalize=False).index.tolist())}
                    t_dict.update({'name': mp})
                    dict_list.append(t_dict)

                mydict = {'Main'+str(i+1):name for i,name in enumerate(dict_list)}

                f = open(model_path + '/Product_Dictionary.pkl','wb')
                pickle.dump(mydict,f)
                f.close()
                
                print("-- Dictionary for Main & Sub Product classes created and saved --\n")
                with open(model_path + '/Product_Dictionary.pkl', 'rb') as pickle_file:
                    mydict = pickle.load(pickle_file)

        if mp_name is None:            
            self.model_data['anon_labels'] = self.model_data['MAIN_PRODUCT'].swifter.progress_bar(False).apply(lambda x: self.__get_key(mydict, x))

        else:
            mp_id = self.__get_key(mydict, mp_name)
            self.model_data = self.model_data[self.model_data['MAIN_PRODUCT']==mp_name]
            self.model_data['anon_labels'] = self.model_data['SUB_PRODUCT'].swifter.progress_bar(False).apply(lambda x: self.__get_key(mydict, x, mp_id))


            
    # evaluates the Accuracy, Precision and Recall
    def __eval_class(self, actual_class, predicted_class):
        acc = accuracy_score(actual_class, predicted_class)
        rec = recall_score(actual_class, predicted_class, average='weighted')
        pre = precision_score(actual_class, predicted_class, average='weighted')
        f1s = f1_score(actual_class, predicted_class, average='weighted')
        print("Accuracy: \t"+ str(round(acc,3)))
        print("Recall: \t" + str(round(rec,3)))
        print("Precision: \t" + str(round(pre,3)))
        print("F1 Score: \t" + str(round(f1s,3)))
        return (acc, rec, pre, f1s)

        
    
    def __FastText_train(self, df, **kwargs):
        
        if not os.path.exists(Path(MODEL_PATH).resolve().as_posix()+"/FastText"):
            os.mkdir(Path(MODEL_PATH).resolve().as_posix()+"/FastText")
            
        print('-- Training based on FastText Algorithm --\n\n')
        
        data_path = Path(DATA_PATH).resolve().as_posix()
        model_path = Path(MODEL_PATH).resolve().as_posix()
        
        df['labels_text'] = '__label__' + df['anon_labels'].astype(str)
        df = df[['anon_labels','COMPLAINT_TEXT', 'labels_text']]
        df['labels_text'] = df['labels_text'].str.cat(df['COMPLAINT_TEXT'], sep=' ')

        print('-- Creating Train & Test split with 80:20 Ratio --\n')       
        df_train, df_test = train_test_split(df, test_size=0.2, random_state =42)

        print('-- Building FastText Supervised Model without Word Vectors --\n')      
        train_file = open(model_path + '/FastText/train.txt','w')
        train_file.writelines(df_train['labels_text'] + '\n')
        train_file.close()
        
        ws = kwargs.get("ws", 7)
        lr = kwargs.get("lr", 0.05)
        dim = kwargs.get("dim", 300)
        wordNgrams = kwargs.get("wordNgrams", 2)
        epoch = kwargs.get("epoch", 100)
        mp_id = kwargs.get("mp_id", None)

        classifier = ft.train_supervised(model_path + '/FastText/train.txt', ws=ws, lr=lr, dim=dim, 
                                         wordNgrams=wordNgrams, epoch=epoch)
        if mp_id is None:
            classifier.save_model(model_path+'/FastText/'+'MainProduct_Model.ftz')
        else:
            classifier.save_model(model_path+'/FastText/'+mp_id+'_Model.ftz')
            
        print('-- FastText Model developed and saved successfully --\n') 

#         print(classifier.test_label())
        predictions = classifier.predict(df_test['COMPLAINT_TEXT'].tolist(),k=1,threshold=0.0)
        pred_class = pd.Series(self.__flatten(predictions[0]), name='Pred_Class').swifter.progress_bar(False).apply(lambda x: re.sub('__label__', '', x))
        pred_score = pd.Series(self.__flatten(predictions[1]), name='Pred_Score').to_numpy()
        print('-- Model Evaluation Metrics -- \n')
        acc, rec, pre, f1s = self.__eval_class(df_test['anon_labels'], pred_class)
        print('\n\n')
        
        
    
    def __get_model_name(self, model):
        x = re.sub("\n", "", str(model))
        x = re.sub(" +", " ", x)
        model_name = x[:x.find("(")]
        return model_name
        
        
        
    def __ML_train(self, df, **kwargs):
        
        if not os.path.exists(Path(MODEL_PATH).resolve().as_posix()+"/ML"):
            os.mkdir(Path(MODEL_PATH).resolve().as_posix()+"/ML")
            
        print('-- Training based on Machine Learning Algorithm --\n\n')
        
        mp_id = kwargs.get("mp_id", None)
        data_path = Path(DATA_PATH).resolve().as_posix()
        model_path = Path(MODEL_PATH).resolve().as_posix()
        
        dfX = df['COMPLAINT_TEXT']
        dfY = df['anon_labels']
       
        print('-- Creating Train & Test split with 80:20 Ratio --\n')
        train_df, test_df, y_train, y_test = train_test_split(dfX, dfY.values,test_size=0.2, random_state=42)
        tfidf_vectorizer = TfidfVectorizer(max_features = 300, sublinear_tf=True, use_idf=True, 
                                           norm='l2', ngram_range=(1, 3), stop_words = 'english')
        train_df = tfidf_vectorizer.fit_transform(train_df)
        
        if mp_id is None:
            tfidf_file_name = 'MainProduct_TFIDF.pkl'
        else:
            tfidf_file_name = mp_id+'_TFIDF.pkl'
        
        f = open(model_path + '/ML/' + tfidf_file_name,'wb')
        pickle.dump(tfidf_vectorizer,f)
        f.close()
        
        with open(model_path + '/ML/' + tfidf_file_name, 'rb') as pickle_file:
            tfidf_vectorizer = pickle.load(pickle_file)
        
        test_df = tfidf_vectorizer.transform(test_df)
        
        
        if mp_id is None:
            mod_file_name = 'MainProduct_Model.pkl'
        else:
            mod_file_name = mp_id+'_Model.pkl'
        
        
        print('-- Building different ML Supervised Model with TFIDF --\n')
        models = [RandomForestClassifier(n_estimators=100, max_depth=4, random_state=42), 
                  SVC(C=5.0, kernel='rbf', gamma='auto', probability=1, random_state=42), 
#                   LinearSVC(random_state=42),
                  MultinomialNB(),
                  GradientBoostingClassifier(loss='deviance',learning_rate=0.1,n_estimators=100,max_depth=3,random_state=42), 
                  LogisticRegression(random_state=42, C=5.0), 
                  SGDClassifier(loss='modified_huber', penalty='elasticnet', random_state=42) 
                  ]
        
        max_acc = 0.0
        for model in models:
            model_name = self.__get_model_name(model)
            model.fit(train_df, y_train)
            pred_class = pd.Series(model.predict(test_df), name='Pred_Class')
            pred_score = pd.Series(model.predict_proba(test_df).max(axis=1), name='Pred_Score')
            print('-- ' + model_name + ' Evaluation Metrics -- \n')
            acc, rec, pre, f1s = self.__eval_class(y_test, pred_class)
            print('\n\n')
            if acc > max_acc:
                max_acc = acc
                joblib.dump(model, model_path+'/ML/'+mod_file_name)
                print('-- Successfully saved ' + model_name + ' for best Accuracy -- \n\n')
            
        return 
        
        
      
    def __create_DL_model(self, labels, vocab=20000, emb_dim=300, max_length=300):
        model = Sequential()
        model.add(Embedding(vocab, emb_dim, input_length=max_length))
        model.add(Bidirectional(LSTM(64, dropout=0.1, recurrent_dropout=0.1)))
        model.add(Dense(32, activation = "relu"))
        model.add(Dropout(0.1))
        model.add(Dense(labels.shape[1], activation='softmax'))
        model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
        model.summary()
        return model


    def __DL_train(self, df, **kwargs):
        
        if not os.path.exists(Path(MODEL_PATH).resolve().as_posix()+"/DL"):
            os.mkdir(Path(MODEL_PATH).resolve().as_posix()+"/DL")
            
        print('-- Training based on Deep Learning Algorithm --\n\n')
        
        mp_id = kwargs.get("mp_id", None)
        data_path = Path(DATA_PATH).resolve().as_posix()
        model_path = Path(MODEL_PATH).resolve().as_posix()
        
        vocab = kwargs.get("vocab", 20000)
        emb_dim = kwargs.get("emb_dim", 300)
        max_length = kwargs.get("max_length", 500)
        
        epochs = kwargs.get("epochs", 2)
        batch_size = kwargs.get("batch_size", 64)
        mp_id = kwargs.get("mp_id", None)
        
        tokenizer = Tokenizer(num_words= vocab)
        tokenizer.fit_on_texts(df['COMPLAINT_TEXT'].values)
        
        if mp_id is None:
            tok_file_name = 'MainProduct_TOK.pkl'
        else:
            tok_file_name = mp_id+'_TOK.pkl'
        
        with open(model_path + '/DL/' + tok_file_name, 'wb') as handle:
            pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)
        
        sequences = tokenizer.texts_to_sequences(df['COMPLAINT_TEXT'].values)
        data = pad_sequences(sequences, maxlen=max_length)
        le = LabelEncoder()
        labs = le.fit_transform(df['anon_labels'])
        labels = to_categorical(labs, num_classes = max(labs)+1)
        
        if mp_id is None:
            lab_file_name = 'MainProduct_LAB.npy'
        else:
            lab_file_name = mp_id+'_LAB.npy'
        
        np.save(model_path + '/DL/' + lab_file_name, le.classes_)

        
        print('-- Creating Train & Test split with 80:20 Ratio --\n')
        X_train, X_test, y_train, y_test = train_test_split(data , labels, test_size=0.2, random_state=42)
        
        if mp_id is None:
            mod_file_name = 'MainProduct_Model.h5'
        else:
            mod_file_name = mp_id+'_Model.h5'
        
        print('-- Building Deep Learning Supervised Model with Embedding Layer --\n')
        checkpoint = ModelCheckpoint(model_path + '/DL/' + mod_file_name, monitor='val_loss', verbose=1, 
                                     save_best_only=True, mode='min')
        model = self.__create_DL_model(labels, vocab, emb_dim, max_length)
        hist = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2, callbacks = [checkpoint])
        
        model = load_model(model_path + '/DL/' + mod_file_name)
        
        pred_class = pd.Series(model.predict_classes(X_test), name='Pred_Class')
        pred_score = pd.Series(model.predict_proba(X_test).max(axis=1), name='Pred_Score')
        print('-- Model Evaluation Metrics -- \n')
        acc, rec, pre, f1s = self.__eval_class(np.argmax(y_test, axis=1), pred_class)
        print('\n\n')
        
  
     ################## Defining fit and predict ##################    
    
    def fit(self, main_only=False, main_product=None, method='FT', **kwargs):       
        
        data_path = Path(DATA_PATH).resolve().as_posix()
        model_path = Path(MODEL_PATH).resolve().as_posix()

        create_data = kwargs.get("create_data", False)
        sample = kwargs.get("sample", None)

        if not create_data:
            file = data_path+"/clean_data/subset_df.pkl"

            if os.path.isfile(file):
                self.subset_df = pd.read_pickle(file)
                print("Clean Data found and loaded..! \n")

            else:
                print("Clean Data not found. Creating from Raw Files..! \n")
                self.__force_load(data_path, sample)
                self.subset_df = pd.read_pickle(data_path+"/clean_data/subset_df.pkl")
                
        else:
            print("Force creating data from Raw Files..! \n")
            self.__force_load(data_path, sample)
            self.subset_df = pd.read_pickle(data_path+"/clean_data/subset_df.pkl")

        
        if main_only:
            print('-- Developing Classifier Model only for Main Products -- \n')
            self.model_data = self.subset_df
            self.__get_dict(create_data=False)   
            df = self.model_data
            
            if method == 'FT':
                self.__FastText_train(df, **kwargs)
                
            elif method == 'ML':
                self.__ML_train(df, **kwargs)
                
            elif method == 'DL':
                self.__DL_train(df, **kwargs)
            
            else:
                print('-- Need Algorithm for Training. Please enter anyone among (FT|ML|DL) -- \n\n')
                return
            
            return
            
        else:
            if main_product is None:
                print('-- Developing Classifier Model for Main Products -- \n')
                self.model_data = self.subset_df
                self.__get_dict(create_data=False)   
                df = self.model_data
                
                if method == 'FT':
                    self.__FastText_train(df, **kwargs)
                    
                elif method == 'ML':
                    self.__ML_train(df, **kwargs)
                    
                elif method == 'DL':
                    self.__DL_train(df, **kwargs)
                
                else:
                    print('-- Need Algorithm for Training. Please enter anyone among (FT|ML|DL) -- \n\n')
                    return
                
                with open(model_path + '/Product_Dictionary.pkl', 'rb') as pickle_file:
                    mydict = pickle.load(pickle_file)
                mp_list = self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).index.tolist()
            
                for mp in mp_list:
                    print('-- Developing Classifier Model for Sub Products -- \n')
                    print('Main Product is: ' + mp + '\n')
                    self.model_data = self.subset_df
                    self.__get_dict(mp_name=mp,create_data=False) 
                    df = self.model_data
                    mp_id = self.__get_key(mydict, mp)
                    
                    if method == 'FT':
                        self.__FastText_train(df, mp_id=mp_id, **kwargs)
                        
                    elif method == 'ML':
                        self.__ML_train(df, mp_id=mp_id, **kwargs)
                    
                    elif method == 'DL':
                        self.__DL_train(df, mp_id=mp_id, **kwargs)
                        
                    else:
                        print('-- Need Algorithm for Training. Please enter anyone among (FT|ML|DL) -- \n\n')
                        return
                        
            else:
                print('-- Developing Classifier Model only for Sub Products -- \n')
                mp_list = self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).index.tolist()
                mydict = pickle.load(model_path + '/Product_Dictionary.pkl')
                self.model_data = self.subset_df
                if main_product in set(mp_list):
                    print('Main Product is: ' + main_product + '\n')
                    self.__get_dict(mp_name=main_product, create_data=False) 
                    df = self.model_data
                    mp_id = self.__get_key(mydict, main_product)
                    
                    if method == 'FT':
                        self.__FastText_train(df, mp_id=mp_id, **kwargs)
                        
                    elif method == 'ML':
                        self.__ML_train(df, mp_id=mp_id, **kwargs)
                        
                    elif method == 'DL':
                        self.__DL_train(df, mp_id=mp_id, **kwargs)
                        
                    else:
                        print('-- Need Algorithm for Training. Please enter anyone among (FT|ML|DL) -- \n\n')
                        return
                        
                else:
                    print('-- Please provide correct Main Product name. Here are the options: --\n')
                    print(set(mp_list))
                    return
                     
          
    def predict(self, text, main_product=None, method='FT', **kwargs):
        
        data_path = Path(DATA_PATH).resolve().as_posix()
        model_path = Path(MODEL_PATH).resolve().as_posix()
        results_path = Path(RESULTS_PATH).resolve().as_posix()
        
        if method == 'FT':
            if not os.path.exists(Path(RESULTS_PATH).resolve().as_posix()+"/FastText"):
                os.mkdir(Path(RESULTS_PATH).resolve().as_posix()+"/FastText")
            print('-- Prediction to be performed based on FastText Algorithm --\n\n')
                
        elif method == 'ML':
            if not os.path.exists(Path(RESULTS_PATH).resolve().as_posix()+"/ML"):
                os.mkdir(Path(RESULTS_PATH).resolve().as_posix()+"/ML")
            print('-- Prediction to be performed based on ML Algorithm --\n\n')
                
        elif method == 'DL':
            if not os.path.exists(Path(RESULTS_PATH).resolve().as_posix()+"/DL"):
                os.mkdir(Path(RESULTS_PATH).resolve().as_posix()+"/DL")
            print('-- Prediction to be performed based on Deep Learning Algorithm --\n\n')
                
        else:
            print('-- Need Algorithm for Prediction. Please enter anyone among (FT|ML|DL) -- \n\n')
            return
        
        
        file_list = {}
        file_list.update({'Clean_Data': data_path+"/clean_data/subset_df.pkl"})
        
        if not os.path.isfile(file_list.get('Clean_Data')):
            print('-- Clean Data not found in specific location. Please get Clean Data first..! --\n')
            return
        
        else:
            self.subset_df = pd.read_pickle(data_path+"/clean_data/subset_df.pkl")
            mp_list = self.subset_df['MAIN_PRODUCT'].value_counts(normalize=False).index.tolist() 
            file_list.update({'Product_Dictionary': model_path + '/Product_Dictionary.pkl'})
            
            if method == 'FT':
                file_list.update({'MainProduct_Model': model_path + '/FastText/MainProduct_Model.ftz'})
                
            elif method == 'ML':
                file_list.update({'MainProduct_Model': model_path + '/ML/MainProduct_Model.pkl'})
            
            elif method == 'DL':
                file_list.update({'MainProduct_Model': model_path + '/DL/MainProduct_Model.h5'})
                
            else:
                print('-- Need Algorithm for Prediction. Please enter anyone among (FT|ML|DL) -- \n\n')
                return
                
                
            dict_list = []

            for mp in mp_list:
                temp = self.subset_df[self.subset_df['MAIN_PRODUCT']==mp]
                t_dict = {'Sub'+str(i+1):sprd for i,sprd in enumerate(temp['SUB_PRODUCT'].value_counts(normalize=False).index.tolist())}
                t_dict.update({'name': mp})
                dict_list.append(t_dict)

            mydict = {'Main'+str(i+1):name for i,name in enumerate(dict_list)}
            
            for mp in mp_list:
                mp_id = self.__get_key(mydict, mp)
                
                if method == 'FT':
                    file_list.update({mp_id+'_Model': model_path + '/FastText/'+mp_id+'_Model.ftz'})
                    
                elif method == 'ML':
                    file_list.update({mp_id+'_Model': model_path + '/ML/'+mp_id+'_Model.pkl'})
        
                elif method == 'DL':
                    file_list.update({mp_id+'_Model': model_path + '/DL/'+mp_id+'_Model.h5'})
                    
                else:
                    print('-- Need Algorithm for Prediction. Please enter anyone among (FT|ML|DL) -- \n\n')
                    return
        
        
        for file, fpath in file_list.items():
            if not os.path.isfile(fpath):
                print('Expected file at ' + fpath)
                print(file + ' not found. Cannot proceed..!')
                return 
            
            
        print('-- Loading necessary Models --\n')
        with open(model_path + '/Product_Dictionary.pkl', 'rb') as pickle_file:
            Product_Dictionary = pickle.load(pickle_file)
            
        if method == 'FT':
            MainProduct_Model = ft.load_model(file_list.get('MainProduct_Model'))
            
        elif method == 'ML':
            MainProduct_Model = joblib.load(file_list.get('MainProduct_Model'))
            print('-- Loaded ' + self.__get_model_name(MainProduct_Model) + ' as Main Product Model --\n')
                
        elif method == 'DL':
            MainProduct_Model = load_model(file_list.get('MainProduct_Model'))
        
        
        if main_product is None:
            
            if type(text) == str:
                
                print('-- Cleaning the Input -- \n')
                text = self.__pre_process_document(text, label=False)
                print('-- Predicting Main Product --\n')
                
                if method == 'FT':
                    mp_pred = MainProduct_Model.predict(text, k=1, threshold=0.0)
                    mp_id = re.sub('__label__', '', mp_pred[0][0])
                    mp_name = Product_Dictionary.get(mp_id).get('name')
                    mp_conf = mp_pred[1][0]
                    
                elif method == 'ML':
                    with open(model_path + '/ML/MainProduct_TFIDF.pkl', 'rb') as pickle_file:
                        tfidf_vectorizer = pickle.load(pickle_file)
                    temp_list = []
                    temp_list.append(text)
                    test_df = tfidf_vectorizer.transform(temp_list)
                    mp_id = MainProduct_Model.predict(test_df)[0]
                    mp_name = Product_Dictionary.get(mp_id).get('name')
                    mp_conf = MainProduct_Model.predict_proba(test_df).max(axis=1)[0]
                    
                elif method == 'DL':
                    with open(model_path + '/DL/MainProduct_TOK.pkl', 'rb') as pickle_file:
                        tokenizer = pickle.load(pickle_file)
                    max_length = kwargs.get("max_length", 500)
                    sequences = tokenizer.texts_to_sequences(pd.Series(text).values)
                    X_test = pad_sequences(sequences, maxlen=max_length)
                    le = LabelEncoder()
                    le.classes_ = np.load(model_path + '/DL/MainProduct_LAB.npy', allow_pickle=True)
                    mp_id = le.inverse_transform(MainProduct_Model.predict_classes(X_test))[0]
                    mp_name = Product_Dictionary.get(mp_id).get('name')
                    mp_conf = MainProduct_Model.predict_proba(X_test).max(axis=1)[0]
                    
                
                print('MAIN PRODUCT NAME: ' + mp_name)
                print('MAIN PRODUCT CONFIDENCE: ' + str(round(mp_conf*100,1)) + '% \n')
                
                print('-- Predicting Sub Product as per Main Product prediction -- \n')
                
                if method == 'FT':
                    SubProduct_Model = ft.load_model(file_list.get(mp_id+'_Model'))
                    sp_pred = SubProduct_Model.predict(text, k=1, threshold=0.0)
                    sp_id = re.sub('__label__', '', sp_pred[0][0])
                    sp_name = Product_Dictionary.get(mp_id).get(sp_id)
                    sp_conf = sp_pred[1][0]
                    
                elif method == 'ML':
                    with open(model_path + '/ML/'+mp_id+'_TFIDF.pkl', 'rb') as pickle_file:
                        tfidf_vectorizer = pickle.load(pickle_file)
                    SubProduct_Model = joblib.load(file_list.get(mp_id+'_Model'))
                    print('-- Loaded ' + self.__get_model_name(SubProduct_Model) + ' as Sub Product Model --\n')
                    temp_list = []
                    temp_list.append(text)
                    test_df = tfidf_vectorizer.transform(temp_list)
                    sp_id = SubProduct_Model.predict(test_df)[0]
                    sp_name = Product_Dictionary.get(mp_id).get(sp_id)
                    sp_conf = SubProduct_Model.predict_proba(test_df).max(axis=1)[0]
                    
                elif method == 'DL':
                    with open(model_path + '/DL/'+mp_id+'_TOK.pkl', 'rb') as pickle_file:
                        tokenizer = pickle.load(pickle_file)
                    SubProduct_Model = load_model(file_list.get(mp_id+'_Model'))
                    max_length = kwargs.get("max_length", 500)
                    sequences = tokenizer.texts_to_sequences(pd.Series(text).values)
                    X_test = pad_sequences(sequences, maxlen=max_length)
                    le = LabelEncoder()
                    le.classes_ = np.load(model_path + '/DL/'+mp_id+'_LAB.npy', allow_pickle=True)
                    sp_id = le.inverse_transform(SubProduct_Model.predict_classes(X_test))[0]
                    sp_name = Product_Dictionary.get(mp_id).get(sp_id)
                    sp_conf = SubProduct_Model.predict_proba(X_test).max(axis=1)[0]
                                                   
                print('SUB PRODUCT NAME: ' + sp_name)
                print('SUB PRODUCT CONFIDENCE: ' + str(round(sp_conf*100,1)) + '% \n')
                
                
            elif type(text) == pandas.core.series.Series:
                
                print('-- Cleaning the Input -- \n')
                text = text.swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=False))
                print('-- Predicting Main and Sub Product from the corpus --\n')
                
                if method == 'FT':
                    mp_pred = MainProduct_Model.predict(text.tolist(), k=1, threshold=0.0)
                    pred_mp_name = pd.Series(self.__flatten(mp_pred[0]), name='Pred_MP_Name').swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(re.sub('__label__', '', x)).get('name'))
                    pred_mp_conf = pd.Series(self.__flatten(mp_pred[1]), name='Pred_MP_Conf')
                
                elif method == 'ML':
                    with open(model_path + '/ML/MainProduct_TFIDF.pkl', 'rb') as pickle_file:
                        tfidf_vectorizer = pickle.load(pickle_file)
                    test_df = tfidf_vectorizer.transform(text)
                    pred_mp_name = pd.Series(MainProduct_Model.predict(test_df), name='Pred_MP_Name').swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(x).get('name'))
                    pred_mp_conf = pd.Series(MainProduct_Model.predict_proba(test_df).max(axis=1), name='Pred_MP_Conf')
                                                              
                elif method == 'DL':
                    with open(model_path + '/DL/MainProduct_TOK.pkl', 'rb') as pickle_file:
                        tokenizer = pickle.load(pickle_file)
                    max_length = kwargs.get("max_length", 500)
                    sequences = tokenizer.texts_to_sequences(text.values)
                    X_test = pad_sequences(sequences, maxlen=max_length)
                    le = LabelEncoder()
                    le.classes_ = np.load(model_path + '/DL/MainProduct_LAB.npy', allow_pickle=True)
                    pred_mp_name = pd.Series(le.inverse_transform(MainProduct_Model.predict_classes(X_test)), name='Pred_MP_Name').swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(x).get('name'))
                    pred_mp_conf = pd.Series(MainProduct_Model.predict_proba(X_test).max(axis=1), name='Pred_MP_Conf')
                
                mp_df1 = pd.concat([text, pred_mp_name, pred_mp_conf], axis=1)
                
                pred_sp_name = pd.Series(name='Pred_SP_Name')
                pred_sp_conf = pd.Series(name='Pred_SP_Conf')
                
                for mp in pred_mp_name.unique():
                    mp_id = self.__get_key(Product_Dictionary, mp)
                    
                    if method == 'FT':
                        SubProduct_Model = ft.load_model(file_list.get(mp_id+'_Model'))
                        sub_text = mp_df1[text.name][mp_df1['Pred_MP_Name'] == mp]
                        sub_text_index = sub_text.index
                        sp_pred = SubProduct_Model.predict(sub_text.tolist(), k=1, threshold=0.0)
                        temp_sp_name = pd.Series(self.__flatten(sp_pred[0]), name='Pred_SP_Name', index=sub_text_index).swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(mp_id).get(re.sub('__label__', '', x)))
                        temp_sp_conf = pd.Series(self.__flatten(sp_pred[1]), name='Pred_SP_Conf', index=sub_text_index)

                    elif method == 'ML':
                        with open(model_path + '/ML/'+mp_id+'_TFIDF.pkl', 'rb') as pickle_file:
                            tokenizer = pickle.load(pickle_file)
                        SubProduct_Model = joblib.load(file_list.get(mp_id+'_Model'))
                        print('-- Loaded ' + self.__get_model_name(SubProduct_Model) + ' as Sub Product Model --\n')
                        sub_text = mp_df1[text.name][mp_df1['Pred_MP_Name'] == mp]
                        sub_text_index = sub_text.index
                        test_df = tfidf_vectorizer.transform(sub_text)
                        temp_sp_name = pd.Series(SubProduct_Model.predict(test_df), name='Pred_SP_Name', index=sub_text_index).swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(mp_id).get(x))
                        temp_sp_conf = pd.Series(SubProduct_Model.predict_proba(test_df).max(axis=1), name='Pred_SP_Conf', index=sub_text_index)
                        
                    elif method == 'DL':
                        with open(model_path + '/DL/'+mp_id+'_TOK.pkl', 'rb') as pickle_file:
                            tfidf_vectorizer = pickle.load(pickle_file)
                        SubProduct_Model = load_model(file_list.get(mp_id+'_Model'))
                        max_length = kwargs.get("max_length", 500)
                        sub_text = mp_df1[text.name][mp_df1['Pred_MP_Name'] == mp]
                        sub_text_index = sub_text.index
                        sequences = tokenizer.texts_to_sequences(sub_text.values)
                        X_test = pad_sequences(sequences, maxlen=max_length)
                        le = LabelEncoder()
                        le.classes_ = np.load(model_path + '/DL/' + mp_id+'_LAB.npy', allow_pickle=True)
                        temp_sp_name = pd.Series(le.inverse_transform(SubProduct_Model.predict_classes(X_test)), name='Pred_SP_Name', index=sub_text_index).swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(mp_id).get(x))
                        temp_sp_conf = pd.Series(SubProduct_Model.predict_proba(X_test).max(axis=1), name='Pred_SP_Conf', index=sub_text_index)

                    pred_sp_name = pred_sp_name.append(temp_sp_name)
                    pred_sp_conf = pred_sp_conf.append(temp_sp_conf)
                
                mp_df1 = pd.concat([mp_df1, pred_sp_name, pred_sp_conf], axis=1)
                
                if method == 'FT':
                    mp_df1.to_pickle(results_path+'/FastText/Predicted_Data.pkl')
                    
                elif method == 'ML':
                    mp_df1.to_pickle(results_path+'/ML/Predicted_Data.pkl')

                elif method == 'DL':
                    mp_df1.to_pickle(results_path+'/DL/Predicted_Data.pkl')
                    
                print('DataFrame created with predictions and saved.')
                return mp_df1

            else:
                print('-- Only String and Pandas Series Type is Supported for this method -- \n')
                
        else:
            if main_product in set(mp_list):
                
                if type(text) == str:
                    
                    print('-- Cleaning the Input -- \n')
                    text = self.__pre_process_document(text, label=False)
                    print('-- Predicting Sub Product as per Main Product selection -- \n')
                    mp_id = self.__get_key(Product_Dictionary, main_product)
                    
                    if method == 'FT':
                        SubProduct_Model = ft.load_model(file_list.get(mp_id+'_Model'))
                        sp_pred = SubProduct_Model.predict(text, k=1, threshold=0.0)
                        sp_id = re.sub('__label__', '', sp_pred[0][0])
                        sp_name = Product_Dictionary.get(mp_id).get(sp_id)
                        sp_conf = sp_pred[1][0]
                    
                    elif method == 'ML':
                        with open(model_path + '/ML/'+mp_id+'_TFIDF.pkl', 'rb') as pickle_file:
                            tfidf_vectorizer = pickle.load(pickle_file)
                        SubProduct_Model = joblib.load(file_list.get(mp_id+'_Model'))
                        print('-- Loaded ' + self.__get_model_name(SubProduct_Model) + ' as Sub Product Model --\n')
                        temp_list = []
                        temp_list.append(text)
                        test_df = tfidf_vectorizer.transform(temp_list)
                        sp_id = SubProduct_Model.predict(test_df)[0]
                        sp_name = Product_Dictionary.get(mp_id).get(sp_id)
                        sp_conf = SubProduct_Model.predict_proba(test_df).max(axis=1)[0]     

                    elif method == 'DL':
                        with open(model_path + '/DL/'+mp_id+'_TOK.pkl', 'rb') as pickle_file:
                            tokenizer = pickle.load(pickle_file)
                        SubProduct_Model = load_model(file_list.get(mp_id+'_Model'))
                        max_length = kwargs.get("max_length", 500)
                        sequences = tokenizer.texts_to_sequences(pd.Series(text).values)
                        X_test = pad_sequences(sequences, maxlen=max_length)
                        le = LabelEncoder()
                        le.classes_ = np.load(model_path + '/DL/'+mp_id+'_LAB.npy', allow_pickle=True)
                        sp_id = le.inverse_transform(SubProduct_Model.predict_classes(X_test))[0]
                        sp_name = Product_Dictionary.get(mp_id).get(sp_id)
                        sp_conf = SubProduct_Model.predict_proba(X_test).max(axis=1)[0]
  
                
                    print('SUB PRODUCT NAME: ' + sp_name)
                    print('SUB PRODUCT CONFIDENCE: ' + str(round(sp_conf*100,1)) + '% \n')
                                                                                                                                               
                
                elif type(text) == pandas.core.series.Series:
                    
                    print('-- Cleaning the Input -- \n')
                    text = text.swifter.progress_bar(False).apply(lambda x: self.__pre_process_document(x, label=False))
                    print('-- Predicting Sub Product as per Main Product selection -- \n')
                    mp_id = self.__get_key(Product_Dictionary, main_product)
                    
                    if method == 'FT':
                        SubProduct_Model = ft.load_model(file_list.get(mp_id+'_Model'))                                                                                                            
                        sp_pred = SubProduct_Model.predict(text.tolist(), k=1, threshold=0.0)
                        pred_sp_name = pd.Series(self.__flatten(sp_pred[0]), name='Pred_SP_Name').swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(mp_id).get(re.sub('__label__', '', x)))
                        pred_sp_conf = pd.Series(self.__flatten(sp_pred[1]), name='Pred_SP_Conf')
                        
                    elif method == 'ML':
                        with open(model_path + '/ML/'+mp_id+'_TFIDF.pkl', 'rb') as pickle_file:
                            tfidf_vectorizer = pickle.load(pickle_file)
                        SubProduct_Model = joblib.load(file_list.get(mp_id+'_Model'))
                        print('-- Loaded ' + self.__get_model_name(SubProduct_Model) + ' as Sub Product Model --\n')
                        test_df = tfidf_vectorizer.transform(text)
                        pred_sp_name = pd.Series(SubProduct_Model.predict(test_df), name='Pred_SP_Name').swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(mp_id).get(x))
                        pred_sp_conf = pd.Series(SubProduct_Model.predict_proba(test_df).max(axis=1), name='Pred_SP_Conf')

                    elif method == 'DL':
                        with open(model_path + '/DL/'+mp_id+'_TOK.pkl', 'rb') as pickle_file:
                            tokenizer = pickle.load(pickle_file)
                        SubProduct_Model = load_model(file_list.get(mp_id+'_Model'))
                        max_length = kwargs.get("max_length", 500)
                        sequences = tokenizer.texts_to_sequences(text.values)
                        X_test = pad_sequences(sequences, maxlen=max_length)
                        le = LabelEncoder()
                        le.classes_ = np.load(model_path + '/DL/'+mp_id+'_LAB.npy', allow_pickle=True)
                        temp_sp_name = pd.Series(le.inverse_transform(SubProduct_Model.predict_classes(X_test)), name='Pred_SP_Name').swifter.progress_bar(False).apply(lambda x: Product_Dictionary.get(mp_id).get(x))
                        temp_sp_conf = pd.Series(SubProduct_Model.predict_proba(X_test).max(axis=1), name='Pred_SP_Conf')

                    sp_df1 = pd.concat([text, pred_sp_name, pred_sp_conf], axis=1)
                    
                    if method == 'FT':
                        sp_df1.to_pickle(results_path+'/FastText/'+mp_id+'Predicted_Data.pkl')
                        
                    elif method == 'ML':
                        sp_df1.to_pickle(results_path+'/ML/'+mp_id+'Predicted_Data.pkl')
                                                          
                    elif method == 'DL':
                        sp_df1.to_pickle(results_path+'/DL/'+mp_id+'Predicted_Data.pkl')
                    
                    print('DataFrame created with predictions and saved.')
                    return sp_df1
                                                                                                                                               
                else:
                    print('-- Only String and Pandas Series Type is Supported for this method -- \n')
            
            else:
                print('-- Please provide correct Main Product name. Here are the options: --\n')
                print(set(mp_list))
                return
            
            
        
